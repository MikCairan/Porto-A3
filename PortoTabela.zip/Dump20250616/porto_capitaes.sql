CREATE DATABASE  IF NOT EXISTS `porto` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `porto`;
-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: porto
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `capitaes`
--

DROP TABLE IF EXISTS `capitaes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `capitaes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `idade` int NOT NULL,
  `registroBarcoSendoPilotado` int DEFAULT NULL,
  `quantidadeBarcos` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKRegistro_Barco_idx` (`registroBarcoSendoPilotado`),
  CONSTRAINT `FKRegistro_Barco` FOREIGN KEY (`registroBarcoSendoPilotado`) REFERENCES `barcos` (`registro`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capitaes`
--

LOCK TABLES `capitaes` WRITE;
/*!40000 ALTER TABLE `capitaes` DISABLE KEYS */;
INSERT INTO `capitaes` VALUES (1,'Ernesto',56,21,12),(4,'Paulo',45,22,13),(5,'Guilherme',34,24,23),(6,'Fábio',25,25,12),(7,'Maria',55,26,10),(8,'Osvaldo',46,12,19),(9,'Reinaldo',58,10,18),(10,'Kali',39,29,18),(15,'Roberto',40,20,10),(16,'Erasmo',30,19,12),(17,'João',31,NULL,NULL),(18,'José',52,NULL,NULL),(19,'Yuri',56,NULL,NULL),(21,'Pedro',78,30,14),(22,'Mariane',59,31,5),(24,'Luíza',30,NULL,7);
/*!40000 ALTER TABLE `capitaes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-16 21:03:59
