package com.example.projeto03.dominio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DominioApplicationTests {

	@Test
	void contextLoads() {
	}

}
