package projetoA3.Porto;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CargasRepository extends JpaRepository<Cargas, Integer>{
    boolean existsByCodigo(Integer codigo);
}
