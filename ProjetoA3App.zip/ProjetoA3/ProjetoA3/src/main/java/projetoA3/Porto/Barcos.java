package projetoA3.Porto;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table (name = "barcos")
public class Barcos {
	public Barcos() {
    }

    public Barcos(Integer registro, String nome, Integer anosEmMar, Integer idCapitao, Integer codigoCarga) {
        this.registro = registro;
        this.nome = nome;
        this.anosEmMar = anosEmMar;
        this.idCapitao = idCapitao;
        this.codigoCarga = codigoCarga;
    }

    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "registro", unique = true)
	private Integer registro;
	
	@Column(name = "nome", nullable = false)
    @NotBlank(message = "O campo nome não pode estar em branco")
	private String nome;
	
	@Column(name = "anosEmMar", nullable = false)
    @NotNull(message = "O campo anosEmMar não pode estar em branco")
	private Integer anosEmMar;
	
	@Column(name = "idCapitao")
	private Integer idCapitao;
	
	@Column(name = "codigoCarga")
	private Integer codigoCarga;

    public Integer getRegistro() {
        return registro;
    }

    public void setRegistro(Integer registro) {
        this.registro = registro;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getAnosEmMar() {
        return anosEmMar;
    }

    public void setAnosEmMar(Integer anosEmMar) {
        this.anosEmMar = anosEmMar;
    }

    public Integer getIdCapitao() {
        return idCapitao;
    }

    public void setIdCapitao(Integer idCapitao) {
        this.idCapitao = idCapitao;
    }

    public Integer getCodigoCarga() {
        return codigoCarga;
    }

    public void setCodigoCarga(Integer codigoCarga) {
        this.codigoCarga = codigoCarga;
    }	
}

