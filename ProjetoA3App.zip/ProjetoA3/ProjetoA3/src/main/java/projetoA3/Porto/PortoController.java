package projetoA3.Porto;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/porto")
public class PortoController {
    @Autowired
	CapitaoRepository capitaoRepository;
	@Autowired
	BarcosRepository barcosRepository;
	@Autowired
	CargasRepository cargasRepository;

	@GetMapping
	public ResponseEntity<?> buscarTodos() {
		Map<String, Object> resultado = new HashMap<>();
		resultado.put("Capitães", capitaoRepository.findAll());
    	resultado.put("Barcos", barcosRepository.findAll());
    	resultado.put("Cargas", cargasRepository.findAll());
		return ResponseEntity.ok(resultado);
	}

	@PostMapping("/capitaes")
	public ResponseEntity<?> salvarCapitoes(@Valid @RequestBody Capitao capitao) {
		if(capitao.getRegistroBarcoSendoPilotado() != null){
			boolean barcoExiste = barcosRepository.existsByRegistro(capitao.getRegistroBarcoSendoPilotado());
			if (!barcoExiste) {
				return ResponseEntity.badRequest().body("registroBarco inválido: registro de barco não encontrado");
			}
		}
		Capitao p = capitaoRepository.save(capitao);
		return ResponseEntity.status(HttpStatus.CREATED).body(p);
	}

	@PutMapping("/capitaes/{id}")
	public ResponseEntity<?> atualizarCapitoes(@Valid @RequestBody Capitao capitaoNovo, @PathVariable Integer id) {
		Optional<Capitao> optCapitao = capitaoRepository.findById(id);
		if (optCapitao.isPresent()) {
			if(capitaoNovo.getRegistroBarcoSendoPilotado() != null){
				boolean barcoExiste = barcosRepository.existsByRegistro(capitaoNovo.getRegistroBarcoSendoPilotado());
				if (!barcoExiste) {
					return ResponseEntity.badRequest().body("registroBarco inválido: registro de barco não encontrado");
				}
			}
			Capitao capitaoExistente = optCapitao.get();
			capitaoExistente.setNome(capitaoNovo.getNome());
			capitaoExistente.setIdade(capitaoNovo.getIdade());
			capitaoExistente.setRegistroBarcoSendoPilotado(capitaoNovo.getRegistroBarcoSendoPilotado());
			capitaoExistente.setQuantidadeBarcos(capitaoNovo.getQuantidadeBarcos());

			Capitao p = capitaoRepository.save(capitaoExistente);
			return ResponseEntity.status(HttpStatus.CREATED).body(p);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Capitão não encontrado");
		}
	}
	
	@GetMapping("/capitaes")
	public ResponseEntity<?> buscarCapitoes() {
		return ResponseEntity.ok(capitaoRepository.findAll());
	}

	@GetMapping("/capitaes/{id}")
	public ResponseEntity<?> buscarIdCapitoes(@PathVariable Integer id) {
		Optional<Capitao> optCapitao = capitaoRepository.findById(id);
		if (optCapitao.isPresent()) {
			return ResponseEntity.ok(optCapitao.get());
		}else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Capitão não encontrado");
		}
	}

	@DeleteMapping("/capitaes/{id}")
	public ResponseEntity<?> excluirCapitoes(@PathVariable Integer id) {
		if (capitaoRepository.existsById(id)) {
			capitaoRepository.deleteById(id);
		    return ResponseEntity.status(HttpStatus.OK).body("Capitão deletado com sucesso");

		}
	    return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Capitão não encontrado");

	}

	@PostMapping("/barcos")
	public ResponseEntity<?> salvarBarcos(@Valid @RequestBody Barcos barcos) {
		if(barcos.getIdCapitao() != null){
			boolean capitaoExiste = capitaoRepository.existsById(barcos.getIdCapitao());
			if (!capitaoExiste) {
				return ResponseEntity.badRequest().body("idCapitao inválido: id de capitão não encontrado");
			}
		}
		if(barcos.getCodigoCarga() != null){
			boolean cargaExiste = cargasRepository.existsByCodigo(barcos.getCodigoCarga());
			if (!cargaExiste) {
				return ResponseEntity.badRequest().body("codigoCarga inválido: código de carga não encontrado");
			}
		}
		Barcos b = barcosRepository.save(barcos);
		return ResponseEntity.status(HttpStatus.CREATED).body(b);
	}

	@PutMapping("/barcos/{id}")
	public ResponseEntity<?> atualizarBarcos(@Valid @RequestBody Barcos barcoNovo, @PathVariable Integer id) {
		Optional<Barcos> optBarcos = barcosRepository.findById(id);
			if (optBarcos.isPresent()) {
				if(barcoNovo.getIdCapitao() != null){
				boolean capitaoExiste = capitaoRepository.existsById(barcoNovo.getIdCapitao());
				if (!capitaoExiste) {
					return ResponseEntity.badRequest().body("idCapitao inválido: id de capitão não encontrado");
				}
			}
			if(barcoNovo.getCodigoCarga() != null){
				boolean cargaExiste = cargasRepository.existsByCodigo(barcoNovo.getCodigoCarga());
				if (!cargaExiste) {
					return ResponseEntity.badRequest().body("codigoCarga inválido: código de carga não encontrado");
				}
			}
			Barcos barcoExistente = optBarcos.get();
			barcoExistente.setNome(barcoNovo.getNome());
			barcoExistente.setAnosEmMar(barcoNovo.getAnosEmMar());
			barcoExistente.setIdCapitao(barcoNovo.getIdCapitao());
			barcoExistente.setCodigoCarga(barcoNovo.getCodigoCarga());

			Barcos b = barcosRepository.save(barcoExistente);
			return ResponseEntity.status(HttpStatus.CREATED).body(b);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Barco não encontrado");
		}
	}
	
	@GetMapping("/barcos")
	public ResponseEntity<?> buscarBarcos() {
		return ResponseEntity.ok(barcosRepository.findAll());
	}

	@GetMapping("/barcos/{id}")
	public ResponseEntity<?> buscarIdBarcos(@PathVariable Integer id) {
		Optional<Barcos> optBarcos = barcosRepository.findById(id);
		
		if (optBarcos.isPresent()) {
			return ResponseEntity.ok(optBarcos.get());
		}else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Barco não encontrado");
		}
	}

	@DeleteMapping("/barcos/{id}")
	public ResponseEntity<?> excluirBarcos(@PathVariable Integer id) {
		if (barcosRepository.existsById(id)) {
			barcosRepository.deleteById(id);
		    return ResponseEntity.status(HttpStatus.OK).body("Barco deletado com sucesso"); 

		}
	    return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Barco não encontrado");

	}

	@PostMapping("/cargas")
	public ResponseEntity<?> salvarCargas(@Valid @RequestBody Cargas cargas) {
		Cargas c = cargasRepository.save(cargas);
		return ResponseEntity.status(HttpStatus.CREATED).body(c);
	}

	@PutMapping("/cargas/{id}")
	public ResponseEntity<?> atualizarCargas(@Valid @RequestBody Cargas cargaNova, @PathVariable Integer id) {
		Optional<Cargas> optCargas = cargasRepository.findById(id);
		if (optCargas.isPresent()) {
			Cargas cargaExistente = optCargas.get();
			cargaExistente.setConteudo(cargaNova.getConteudo());
			cargaExistente.setPesoToneladas(cargaNova.getPesoToneladas());
			cargaExistente.setNumCaixas(cargaNova.getNumCaixas());

			Cargas c = cargasRepository.save(cargaExistente);
			return ResponseEntity.status(HttpStatus.CREATED).body(c);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Carga não encontrada");
		}
	}
	
	@GetMapping("/cargas")
	public ResponseEntity<?> buscarCargas() {
		return ResponseEntity.ok(cargasRepository.findAll());
	}

	@GetMapping("/cargas/{id}")
	public ResponseEntity<?> buscarIdCargas(@PathVariable Integer id) {
		Optional<Cargas> optCargas = cargasRepository.findById(id);
		
		if (optCargas.isPresent()) {
			return ResponseEntity.ok(optCargas.get());
		}else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Carga não encontrada");
		}
	}

	@DeleteMapping("/cargas/{id}")
	public ResponseEntity<?> excluirCargas(@PathVariable Integer id) {
		if (cargasRepository.existsById(id)) {
			cargasRepository.deleteById(id);
		    return ResponseEntity.status(HttpStatus.OK).body("Carga deleta com sucesso");

		}
	    return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Carga não encontrada");

	}

}
