package projetoA3.Porto;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table (name = "cargas")
public class Cargas {
	public Cargas() {
    }

    public Cargas(Integer codigo, String conteudo, Double pesoToneladas, Integer numCaixas) {
        this.codigo = codigo;
        this.conteudo = conteudo;
        this.pesoToneladas = pesoToneladas;
        this.numCaixas = numCaixas;
    }

    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "codigo", unique = true)
	private Integer codigo;
	
	@Column(name = "conteudo", nullable = false)
    @NotBlank(message = "O campo conteudo não pode estar em branco")
	private String conteudo;
	
	@Column(name = "pesoToneladas", nullable = false)
    @NotNull(message = "O campo pesoToneladas não pode estar em branco")
	private Double pesoToneladas;
	
	@Column(name = "numCaixas", nullable = false)
    @NotNull(message = "O campo numCaixas não pode estar em branco")
	private Integer numCaixas;

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getConteudo() {
        return conteudo;
    }

    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }

    public Double getPesoToneladas() {
        return pesoToneladas;
    }

    public void setPesoToneladas(Double pesoToneladas) {
        this.pesoToneladas = pesoToneladas;
    }

    public Integer getNumCaixas() {
        return numCaixas;
    }

    public void setNumCaixas(Integer numCaixas) {
        this.numCaixas = numCaixas;
    }	
}

