package projetoA3.Porto;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CapitaoRepository extends JpaRepository<Capitao, Integer>{
    boolean existsById(Integer id);
}
