package projetoA3.Porto;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BarcosRepository extends JpaRepository<Barcos, Integer>{
    boolean existsByRegistro(Integer registro);
}
